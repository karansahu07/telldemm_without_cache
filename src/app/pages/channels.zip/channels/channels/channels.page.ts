import { Component, OnInit } from '@angular/core';
import { IonicModule, ModalController, ToastController } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RegionFilterModalComponent } from '../modals/region-filter-modal/region-filter-modal.component';
import { AddChannelModalComponent } from '../modals/add-channel-modal/add-channel-modal.component';
import { ChannelService, Category, Region, Channel } from '../services/channel';
import { firstValueFrom } from 'rxjs';
import { AuthService } from 'src/app/auth/auth.service';

interface GroupedCategory {
  id: number | 'uncategorized';
  name: string;
  channels: any[];
}

interface UIChannel {
  id: string;
  name: string;
  followers: number;
  followersFormatted: string;
  avatar: string | null;
  verified: boolean;
  following: boolean;
  _meta: any;
}

@Component({
  selector: 'app-channels',
  templateUrl: './channels.page.html',
  styleUrls: ['./channels.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule],
})
export class ChannelsPage implements OnInit {
  isLoading = false;

  allChannels: UIChannel[] = [];
  categories: Category[] = [];
  regions: Region[] = [];

  // ADD THESE PROPERTIES at the top with others
  // userId: number = 52; // ← Replace with real auth user ID later
  userId: any = this.authService.authData?.userId || ''; // Replace with real auth user ID later

  loadingChannelId: string | null = null; // for button loading state
  private followedChannelIds = new Set<string>(); // source of truth

  // ADD THIS METHOD – detects if user owns the channel
  isOwner(channel: UIChannel): boolean {
    return channel._meta?.created_by === this.userId;
  }

  // for category paging (main page)
  private loadedCategoryIds = new Set<number | 'uncategorized'>();

  // for category-full-view channel dedupe
  private categoryChannelIds = new Set<string>();

  allGroupedCategories: GroupedCategory[] = [];
  pagedGroupedCategories: GroupedCategory[] = [];
  categoriesPageSize = 10;
  currentCategoryPage = 0;
  hasMoreCategories = true;

  // filter segment
  selectedCategoryId: number | 'all' = 'all';
  selectedRegionId: number | 'all' = 'all';

  // placeholder
  placeholderAvatar = 'assets/channel/channel-placeholder.svg';

  // Category Full-View state (for See all in-place)
  categoryFullViewActive = false;
  activeCategoryId: number | 'uncategorized' | 'all' = 'all';
  activeCategoryName = '';
  categoryChannels: UIChannel[] = [];
  categoryPageSize = 10;
  categoryOffset = 0; // page index (0-based)
  hasMoreCategoryChannels = true;

  selectedCategoryName?: string | null = null;
  selectedRegionName?: string | null = null;

  constructor(
    private modalCtrl: ModalController,
    private router: Router,
    private channelService: ChannelService,
    private toastCtrl: ToastController,
    private authService: AuthService
  ) { }

  async ngOnInit() {
    await this.loadMetadata();
    // ← ADD THIS: Load your followed channels so we know what you're following
    await this.loadMyFollowedChannels();
    await this.loadChannels();
  }

  private async loadMyFollowedChannels() {
    try {
      const res = await firstValueFrom(
        this.channelService.getUserChannels(this.userId, { role: 'all' })
      );
      if (res?.status && Array.isArray(res.channels)) {
        this.followedChannelIds = new Set(
          res.channels.map((ch: any) => `c${ch.channel_id}`)
        );
      }
    } catch (err) {
      console.warn('Could not load followed channels for sync', err);
    }
  }

  /**
   * Load categories & regions together and wait for both to complete.
   */
  async loadMetadata(): Promise<void> {
    try {
      const [catsRes, regsRes] = await Promise.all([
        firstValueFrom(this.channelService.getAllCategories()),
        firstValueFrom(this.channelService.getAllRegions())
      ]);

      this.categories = (catsRes && (catsRes as any).categories) ? (catsRes as any).categories : [];
      this.regions = (regsRes && (regsRes as any).regions) ? (regsRes as any).regions : [];
    } catch (err) {
      console.warn('Failed to load metadata', err);
      this.categories = [];
      this.regions = [];
    }
  }

  /** Load all channels (used for compact main page grouping) */
  async loadChannels(event?: any) {
    try {
      this.isLoading = true;

      const params: any = {
        page: 1,
        limit: 50 // fetch many to build homepage categories
      };

      // category filter by NAME
      if (this.selectedCategoryId !== 'all') {
        const catObj = this.categories.find(c => c.id == this.selectedCategoryId);
        if (catObj) params.category = catObj.category_name;
      }

      // region filter by NAME
      if (this.selectedRegionId !== 'all') {
        const regionObj = this.regions.find(r => r.region_id == this.selectedRegionId);
        if (regionObj) params.region = regionObj.region_name;
      }

      const res = await firstValueFrom(this.channelService.listChannels(params));
      const backendChannels = Array.isArray(res.channels) ? res.channels : [];

    
      const mapped: UIChannel[] = backendChannels
        .filter((c: any) => {
         
          const channelId = `c${c.channel_id}`;
          const isOwned = c.created_by === this.userId;
          const isFollowed = this.followedChannelIds.has(channelId);

          // HIDE if owned OR followed
          return !isOwned && !isFollowed;
        })
        .map((c: any) => {
         
          const rawFollowers = (c as any).followers_count ?? (c as any).follower_count ?? (c as any).followers ?? 0;
          const followersNum = Number(rawFollowers) || 0;
          // const followersNum = Number(rawFollowers) || 0;
          const channelId = `c${c.channel_id}`;

          return {
            id: channelId,
            name: c.channel_name,
            followers: followersNum,
            followersFormatted: this.formatFollowers(followersNum),
            avatar: c.channel_dp || null,
            verified: !!c.is_verified,
            following: false, // always false here — we filtered them out
            _meta: c
          } as UIChannel;
        });
      this.allChannels = mapped;

      // build categories for main page (first 4 each)
      this.buildAllGroupedCategories(mapped);

      // reset paging
      this.currentCategoryPage = 0;
      this.loadedCategoryIds.clear();
      this.pagedGroupedCategories = [];
      this.hasMoreCategories = true;
      this.loadNextCategoryPage();

    } catch (err) {
      console.error('Load channels error', err);
      await this.presentToast('Could not load channels. Pull to retry.');
    } finally {
      this.isLoading = false;
      if (event?.target) event.target.complete();
    }
  }

  private formatFollowers(n: number): string {
    if (!n || n <= 0) return '0';
    if (n < 1000) return `${n}`;
    if (n < 1_000_000) {
      const num = Math.round((n / 1000) * 10) / 10;
      return `${num}`.replace(/\.0$/, '') + 'k';
    }
    const num = Math.round((n / 1_000_000) * 10) / 10;
    return `${num}`.replace(/\.0$/, '') + 'M';
  }

  private buildAllGroupedCategories(channels: UIChannel[]) {
    const groupsMap = new Map<number | 'uncategorized', GroupedCategory>();
    for (const cat of this.categories) {
      groupsMap.set(cat.id, { id: cat.id, name: cat.category_name, channels: [] });
    }

    for (const ch of channels) {
      const catId = ch._meta?.category_id;
      const key = (catId != null && groupsMap.has(Number(catId))) ? Number(catId) : 'uncategorized';

      if (!groupsMap.has(key)) {
        groupsMap.set(key, { id: key, name: key === 'uncategorized' ? 'Uncategorized' : 'Unknown', channels: [] });
      }

      groupsMap.get(key)!.channels.push(ch);
    }

    const grouped: GroupedCategory[] = [];
    for (const g of groupsMap.values()) {
      if (g.channels && g.channels.length) grouped.push({ id: g.id, name: g.name, channels: g.channels.slice(0, 4) });
    }

    // ensure uncategorized last
    this.allGroupedCategories = grouped.filter(g => g.id !== 'uncategorized');
    const unc = grouped.find(g => g.id === 'uncategorized');
    if (unc) this.allGroupedCategories.push(unc);
  }

  private loadNextCategoryPage() {
    const start = this.currentCategoryPage * this.categoriesPageSize;
    const end = start + this.categoriesPageSize;
    const nextBatch = this.allGroupedCategories.slice(start, end);

    // filter out any groups already loaded (safety)
    const newBatch = nextBatch.filter(g => !this.loadedCategoryIds.has(g.id));

    if (newBatch.length) {
      newBatch.forEach(g => this.loadedCategoryIds.add(g.id));
      this.pagedGroupedCategories = this.pagedGroupedCategories.concat(newBatch);

      this.currentCategoryPage++;

      if (this.pagedGroupedCategories.length >= this.allGroupedCategories.length) {
        this.hasMoreCategories = false;
      }
    } else {
      this.hasMoreCategories = false;
    }
  }

  loadMoreCategories(event: any) {
    // small delay to allow spinner show; keep short
    setTimeout(() => {
      this.loadNextCategoryPage();
      if (event?.target) {
        event.target.complete();
        if (!this.hasMoreCategories) event.target.disabled = true;
      }
    }, 200);
  }

  onCategorySelected(ev: any) {
    const v = ev.detail ? ev.detail.value : ev;
    this.selectedCategoryId = (v === 'all') ? 'all' : Number(v);
    // reset main paging and reload channels with new filter
    this.currentCategoryPage = 0;
    this.hasMoreCategories = true;
    this.loadChannels();
  }


  // REPLACE YOUR toggleFollow() with this PERFECT version
  async toggleFollow(channel: UIChannel) {
    if (this.loadingChannelId === channel.id) return;

    const wasFollowing = channel.following;
    const channelId = channel._meta.channel_id;

    // ───── OPTIMISTIC UI (Instant, no blink) ─────
    channel.following = !wasFollowing;
    channel.followers += wasFollowing ? -1 : 1;
    channel.followersFormatted = this.formatFollowers(channel.followers);

    if (wasFollowing) {
      this.followedChannelIds.delete(channel.id);
    } else {
      this.followedChannelIds.add(channel.id);
    }

    // Update same channel in ALL places (main list + full view)
    this.updateChannelInAllLists(channel.id, {
      following: !wasFollowing,
      followers: channel.followers,
      followersFormatted: channel.followersFormatted
    });

    this.loadingChannelId = channel.id;

    // Haptics (only on device)
    try {
      const { Haptics, ImpactStyle } = await import('@capacitor/haptics');
      Haptics.impact({ style: ImpactStyle.Light });
    } catch (e) { /* web = no haptics */ }

    try {
      await firstValueFrom(
        this.channelService.setFollow(channelId, !wasFollowing)
      );
      // Success → do nothing! Already updated
      this.presentToast(!wasFollowing ? 'Now following' : 'Unfollowed', 800);
    } catch (err) {
      // ───── REVERT ON FAILURE (smooth) ─────
      channel.following = wasFollowing;
      channel.followers += wasFollowing ? 1 : -1;
      channel.followersFormatted = this.formatFollowers(channel.followers);

      if (wasFollowing) {
        this.followedChannelIds.add(channel.id);
      } else {
        this.followedChannelIds.delete(channel.id);
      }

      if (!wasFollowing) {
        // User just followed → remove from ALL explore lists
        this.removeChannelFromExploreViews(channel.id);
      }

      this.updateChannelInAllLists(channel.id, {
        following: wasFollowing,
        followers: channel.followers,
        followersFormatted: channel.followersFormatted
      });

      this.presentToast('Failed. Try again.');
    } finally {
      this.loadingChannelId = null;
    }
  }

  private removeChannelFromExploreViews(channelId: string) {
    // Remove from main grouped categories
    this.allGroupedCategories.forEach(group => {
      group.channels = group.channels.filter(ch => ch.id !== channelId);
    });
    this.pagedGroupedCategories.forEach(group => {
      group.channels = group.channels.filter(ch => ch.id !== channelId);
    });

    // Remove from full category view
    this.categoryChannels = this.categoryChannels.filter(ch => ch.id !== channelId);
  }
  // ADD THIS HELPER – updates channel in all lists (main + full view)
  private updateChannelInAllLists(channelId: string, updates: Partial<UIChannel>) {
    const id = `c${channelId}`;

    // Update in main allChannels
    const inMain = this.allChannels.find(c => c.id === id);
    if (inMain) Object.assign(inMain, updates);

    // Update in grouped categories
    for (const group of this.allGroupedCategories) {
      const ch = group.channels.find(c => c.id === id);
      if (ch) Object.assign(ch, updates);
    }

    // Update in paged view
    for (const group of this.pagedGroupedCategories) {
      const ch = group.channels.find(c => c.id === id);
      if (ch) Object.assign(ch, updates);
    }

    // Update in full category view
    const inFull = this.categoryChannels.find(c => c.id === id);
    if (inFull) Object.assign(inFull, updates);
  }
  async openAddChannelModal() {
    const modal = await this.modalCtrl.create({
      component: AddChannelModalComponent
    });
    await modal.present();

    const { data } = await modal.onDidDismiss();
    if (data) this.loadChannels(); // only reload if created
  }

  async openRegionFilter() {
    const modal = await this.modalCtrl.create({
      component: RegionFilterModalComponent,
      componentProps: {
        regions: this.regions ?? [],
        categories: this.categories ?? [],
      }
    });
    await modal.present();
    const { data } = await modal.onDidDismiss();

    if (!data) return;

    this.applyRegionSelection(data.selectedRegionId ?? null, data.selectedRegionName ?? null);
  }

  private applyRegionSelection(regionId: number | null, regionName: string | null) {
    if (regionId == null) {
      this.selectedRegionId = 'all';
      this.selectedRegionName = null;
    } else {
      this.selectedRegionId = regionId;
      this.selectedRegionName = regionName ?? null;
    }
    // reload channels using new region filter
    this.loadChannels();
  }

  clearRegionFilter() {
    this.selectedRegionId = 'all';
    this.selectedRegionName = null;
    this.loadChannels();
  }

  /** ========== CATEGORY FULL VIEW HANDLERS ========== */
  openCategoryFullView(categoryId: number | 'uncategorized', categoryName?: string) {
    this.categoryFullViewActive = true;
    this.activeCategoryId = categoryId;
    this.activeCategoryName = categoryName ?? (categoryId === 'uncategorized' ? 'Uncategorized' : 'Category');

    this.categoryChannels = [];
    this.categoryOffset = 0;
    this.hasMoreCategoryChannels = true;
    this.categoryChannelIds.clear();

    this.loadCategoryPage();
  }

  closeCategoryFullView() {
    this.categoryFullViewActive = false;
    this.activeCategoryId = 'all';
    this.activeCategoryName = '';
    this.categoryChannels = [];
  }

  async loadCategoryPage(event?: any) {
    if (!this.hasMoreCategoryChannels) {
      if (event?.target) {
        event.target.complete();
        event.target.disabled = true;
      }
      return;
    }

    try {
      const pageToRequest = this.categoryOffset + 1;

      const params: any = {
        page: pageToRequest,
        limit: this.categoryPageSize
      };

      if (this.activeCategoryId !== 'all' && this.activeCategoryId !== 'uncategorized') {
        params.category = this.activeCategoryName;
      }

      if (this.selectedRegionId !== 'all') {
        const regionObj = this.regions.find(r => r.region_id == this.selectedRegionId);
        if (regionObj) params.region = regionObj.region_name;
      }

      const res = await firstValueFrom(this.channelService.listChannels(params));
      const backendChannels = Array.isArray(res.channels) ? res.channels : [];

    

      let filtered = backendChannels.filter((c: any) => {
        const channelId = `c${c.channel_id}`;
        const isOwned = c.created_by === this.userId;
        const isFollowed = this.followedChannelIds.has(channelId);

        // Apply category filter (uncategorized)
        const matchesCategory = this.activeCategoryId === 'uncategorized'
          ? !c.category_name
          : true;

        return matchesCategory && !isOwned && !isFollowed;
      });


      const mapped: UIChannel[] = filtered.map((c: any) => {
        const rawFollowers = (c as any).followers_count ?? (c as any).follower_count ?? (c as any).followers ?? 0;
        const followersNum = Number(rawFollowers) || 0;
        // console.log(followersNum);
        const channelId = `c${c.channel_id}`;

        const isFollowing = this.followedChannelIds.has(channelId);

        return {
          id: channelId,
          name: c.channel_name,
          followers: followersNum,
          followersFormatted: this.formatFollowers(followersNum),
          avatar: c.channel_dp || null,
          verified: !!c.is_verified,
          following: isFollowing, // ← THIS IS THE FIX
          _meta: c
        };
      });

      // dedupe using channel id
      const newOnes = mapped.filter(m => !this.categoryChannelIds.has(m.id));
      newOnes.forEach(n => this.categoryChannelIds.add(n.id));
      this.categoryChannels = [...this.categoryChannels, ...newOnes];

      if (backendChannels.length < this.categoryPageSize) {
        this.hasMoreCategoryChannels = false;
      } else {
        this.categoryOffset += 1; // move to next PAGE
      }

    } catch (err) {
      console.error('Full Category Page Error:', err);
      await this.presentToast('Could not load category channels.');
    } finally {
      if (event?.target) {
        event.target.complete();
        if (!this.hasMoreCategoryChannels) event.target.disabled = true;
      }
    }
  }

 async openChannelDetail(channel: UIChannel) {
  const channelId = channel._meta.channel_id;  // Numeric ID from backend (e.g., 34)
  
  // Navigate to /channel-feed with channelId as query param
  this.router.navigate(['/channel-feed'], { 
    queryParams: { channelId: channelId } 
  });
  
  // Optional: Add haptics for smooth UX (as in toggleFollow)
  try {
    const { Haptics, ImpactStyle } = await import('@capacitor/haptics');
    Haptics.impact({ style: ImpactStyle.Medium });
  } catch (e) { /* No haptics on web */ }
}

  loadMoreCategoryChannels(event: any) {
    setTimeout(() => {
      this.loadCategoryPage(event);
    }, 150);
  }

  trackByChannel(index: number, item: UIChannel) {
    return item.id;
  }

  async presentToast(message: string, duration = 2000) {
    const t = await this.toastCtrl.create({ message, duration, position: 'bottom' });
    await t.present();
  }
}